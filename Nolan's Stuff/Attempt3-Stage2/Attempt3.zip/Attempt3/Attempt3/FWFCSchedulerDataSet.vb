﻿Partial Class FWFCSchedulerDataSet
    Partial Class PreviousWorkDataTable

    End Class

End Class
